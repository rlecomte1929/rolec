# OTTO-G — Ireland (Dublin + Cork) accreditation-registry harvest

**Unblocks:** AIQ-1815 (P1, Blocked) · context for AIQ-1814, AIQ-1817, AIQ-1809
**Wave:** 1 · **Kind:** research · **Otto mode:** chat (+ one authorised write task)
**Everything above the rule is context for us, not for Otto. Paste from the rule down.**

## Why this card exists (operator context)

Measured against production `nsvefcvpvwwwhuqyuqmp` on 2026-08-13:
`supplier_service_capabilities` contains **zero rows with `country_code = 'IE'`**. Not one.
Coverage exists only for AE, DE, NO, SG, US. That is the whole of AIQ-1815 — the ES→IE
corridor ships an empty marketplace and the beta user reaches Services and finds nothing.

The engineering half (allowlist Dublin/Cork, enable IE discovery, `stage()`/`promote()`)
is a Claude Code task and stays here. **The research half — which Irish suppliers are
registry-evidenced — is the part that has no owner, and it is what this card buys.**

Card C proved this exact shape works: 38 registry-evidenced rows, delivered, ingested.
This is Card C with the corridor changed.

---

## The card — paste from here

OTTO-G — Ireland accreditation-registry harvest (research; no browser QA)

WHY THIS CARD EXISTS
An HR buyer's security review will ask where our supplier data came from. "PSRA licence
number 004321, verified 2026-08-13, evidence URL attached" is an answer. A Google Maps
scrape is not. The curation IS the moat, so the sourcing rule below is the point of the
task, not a constraint on it.

You are doing the research half. Someone else writes the database half. You write to no
database and submit no supplier records.

SCOPE — exactly this, nothing adjacent
Destination country: Ireland (IE). Cities: Dublin (primary) and Cork (secondary).
Categories (5): housing_agencies, movers, banks, legal_admin, tax_finance.
That is 10 city x category pairs.

Out of scope, deliberately: schools, rmc, dsp, healthcare_ipmi, language_cultural,
insurance. Do not include them even if you find good candidates.

SOURCING RULE — the one that matters
Every candidate must trace to an accreditation, licensing or membership register that a
third party can check, on the REGISTER'S OWN domain. Irish anchors to try first:

- housing_agencies — Property Services Regulatory Authority (PSRA) public register of
  licensed property services providers. A PSRA licence number is the gold standard here.
  IPAV and SCSI membership are acceptable secondary bodies.
- movers — FIDI Global Alliance / FAIM affiliate directory; IAM; the Irish Household
  Removers Association if it publishes a member list.
- banks — Central Bank of Ireland Register of authorised firms / credit institutions.
- legal_admin — Law Society of Ireland "Find a Solicitor" roll, or the Legal Services
  Regulatory Authority register. A per-firm or per-solicitor record, not a search form.
- tax_finance — Chartered Accountants Ireland member firm directory; Irish Tax Institute
  register of Chartered Tax Advisers (CTA); CPA Ireland.

NOT acceptable as the accreditation evidence: Google Maps, Yelp, Trustpilot, aggregator
"top 10 relocation agents in Dublin" posts, LinkedIn, or the supplier's own marketing
site. The supplier's own site is fine in website_url as a supporting link; it can never be
the value of source_url.

READ THIS — the failure we are trying not to repeat
On the last Norwegian harvest, four rows named "Den Norske Advokatforening" as the
accreditation body but carried an evidence URL pointing at the company register and a
9-digit company registration number in the membership field. Two different claims got
conflated and the rows are now unusable. So:

- accreditation_number must be the number THAT BODY issues (a PSRA licence number, a Law
  Society roll number, a FIDI/FAIM affiliate id). It must NOT be a company registration
  number, a VAT number, or a CRO number. If the register publishes no number, leave the
  field EMPTY. Empty is correct. Invented or substituted fails the row.
- source_url must resolve to a page on the accrediting body's own domain that names THIS
  supplier. Not a search form. Not a directory that merely aggregates the body.
- If you can only confirm the company exists (CRO / Companies Registration Office) but not
  that it holds the accreditation, that is a legitimate finding: set accreditation_body to
  "Companies Registration Office (Ireland)", verification_method to public_registry, and
  confidence to low, and say plainly in notes that this is an ENTITY confirmation only and
  evidences no accreditation.

If a category has no usable register for Ireland, say so and move on. A short honest list
beats a padded one. Target 25-50 rows total. Do not pad to reach 25.

OUTPUT — read this twice, it is the part that has failed before
Write ONE file: audos-workspace-776786/data/otto-g-ie-suppliers.csv

Real CSV, UTF-8, no BOM, with exactly this header row, in this order:

corridor,service_category,company_name,country_code,city_name,website_url,source_name,source_url,accreditation_body,accreditation_number,accreditation_expiry,verification_method,confidence,notes

- corridor is always ES-IE. country_code is always IE. city_name is Dublin or Cork.
- service_category is exactly one of: housing_agencies, movers, banks, legal_admin,
  tax_finance. Spelled exactly as listed — these are database enum values.
- verification_method is exactly one of: public_registry, supplier_document, manual_email,
  directory_listing. Nothing else. "registry_lookup" is NOT a legal value and will be
  rejected by a database constraint on our side, so do not invent it.
- confidence is high, medium or low — your own read on how firm the register match is.
- accreditation_expiry: EMPTY unless the register publishes one. Do not guess a year.
- Quote any field containing a comma.
- One row per supplier per category. A supplier active in two categories gets two rows.

Write a SECOND file: audos-workspace-776786/data/otto-g-gaps.md — one line per
city x category pair you could NOT cover, naming which register you tried and what stopped
you. "NONE", "this register is login-gated" and "PSRA search returns results but no stable
per-licensee URL" are all valid, useful answers. This file is not optional; a batch with no
gaps file is treated as incomplete.

BECAUSE YOU MAY NOT BE ABLE TO WRITE FILES FROM THIS THREAD
If you cannot write files, do BOTH of these and nothing else:
1. Post the rows in this thread as pipe-separated text, same columns in the same order,
   between the exact markers OTTO-G-ROWS-BEGIN and OTTO-G-ROWS-END, one row per line, with
   the header line first. No markdown table. No prose between the markers.
2. NAME the single narrow write task you would run to convert that block to the CSV path
   above — and stop. Do not start it. I will authorise it explicitly.
When I do authorise it, that task converts the block above and NOTHING else: it re-queries
no register, adds no supplier, and changes no value. I will diff the file against the block
line by line, so a "helpful" extra row is a failed batch, not a bonus.

REPORT BLOCK (in the thread, short)
OTTO-G — IRELAND HARVEST      DATE ____
Pairs attempted: __/10
Rows: ____  (high ____ / medium ____ / low ____)
Registers used (name + domain): ____
Pairs with NO usable register: ____
Rows that are ENTITY-ONLY (CRO, no accreditation): ____
Suppliers appearing in >1 category: ____
Anything you were tempted to include but excluded under the sourcing rule: ____

OUTPUT
- Write your findings to audos-workspace-776786/data/otto-g-ie-suppliers.csv and
  audos-workspace-776786/data/otto-g-gaps.md, and sync. Post a short summary here, but the
  FILE is the deliverable. Structured data = CSV or JSON with a header row, not a markdown
  table and not prose. Leave a field EMPTY rather than guessing; a blank is fine, an
  invented value fails the batch.
- Then PROVE the file exists. Run `ls -la audos-workspace-776786/data/` and
  `wc -l audos-workspace-776786/data/otto-g-ie-suppliers.csv` and paste the raw output
  verbatim as the last line of your reply. Do not describe the file, show it. A previous
  card reported "38 rows · data/card-c-harvest.csv" for a file that was never written, and
  we spent a day believing we had the data. If the write failed, say so plainly — a
  reported failure is worth far more to us than an unreported one.

RULES (non-negotiable)
- Spawn no sub-tasks. Create no draft tasks. Do not use Continue in Task. Answer in this
  thread and stop. If follow-on work is needed, NAME it in the report — do not start it.
  ONE exception, and only if the card asks for a file: if you cannot write files from this
  thread, say so and NAME the write task you would run. Do not start it — wait for me to
  authorise it explicitly. Never report a file as written when it was not.
- Record the deploy commit and PROCEED. Never stop on an unfamiliar commit. Stop only if
  /health itself fails (non-200, timeout, no commit field).
- Label every claim [VERIFIED] (you saw it) or [CLAIM] (you inferred it). You cannot see
  our repo, our database or our CDN config — state no facts about them.
- A blocked path is a FINDING, not something to route around. "NONE" is a valid answer.
- Type by keyboard; PageDown for inner scroll containers; click custom controls by
  coordinate, not by ref; use the dropdown for country fields, never type.
- Never touch campaign `insead-2026`. Never set OUTBOX_DISPATCH_CRON_ENABLED. Approve no
  supplier records. Apply no migrations. Delete nothing. Stripe test mode only.
- Write to no database. Submit no supplier records.
- Stop before the budget cap. Never die mid-action.

## When it comes back (operator)

```bash
bash scripts/otto_recover.sh OTTO-G
python3 scripts/otto_verify.py --batch otto-batch.json --card OTTO-G
```

Then the ReloPass half, as a Claude Code task, in this order — the second step is the one
that has silently failed here before ("merged migration != live data", see AIQ-1809 notes):

1. `backend/imports/suppliers/executor.py` `stage()` the CSV → dry-run → human approval →
   `promote()`. Capabilities land `platform_vetting_status='pending'`, never auto-approved.
2. Confirm the rows are LIVE in production, not merely in a migration file:
   `SELECT count(*) FROM supplier_service_capabilities WHERE country_code='IE';`
3. Allowlist Dublin + Cork and enable IE vendor discovery (the AIQ-1815 engineering half).
4. `registry_sources.py` gains a `RegistrySource` entry per Irish anchor actually used.
